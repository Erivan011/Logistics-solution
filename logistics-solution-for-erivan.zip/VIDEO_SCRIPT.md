
# Roteiro para Vídeo (5–7 min)
1) Abertura (10s) — nome do projeto + link do deploy na tela.
2) Problema e Público-Alvo (40s) — dor real e impacto.
3) Solução (40s) — o que o sistema faz.
4) Demo (2–3 min) — EDA, Treinamento, Predição.
5) Arquitetura e Tecnologias (40s) — Streamlit, scikit-learn, Cloud.
6) Equipe e Papéis (30s) — integrantes e responsabilidades.
7) Resultados e Próximos Passos (40s) — métricas e melhorias futuras.
8) Encerramento (10s) — agradecimentos + links.
