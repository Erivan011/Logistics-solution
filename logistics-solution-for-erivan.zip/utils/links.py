
LINKS = {
    'repo': '[https://github.com/Erivan011/Logistics-solution](https://github.com/Erivan011/Logistics-solution)',
    'deploy': '[ADICIONE_AQUI_O_LINK_DE_DEPLOY](https://example.streamlit.app)',
    'video': '[ADICIONE_AQUI_O_LINK_DO_VIDEO](https://youtube.com)'
}
