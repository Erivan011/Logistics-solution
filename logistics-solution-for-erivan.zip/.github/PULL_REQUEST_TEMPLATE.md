
## Descrição

## Evidências

## Checklist
- [ ] README atualizado
- [ ] Links (deploy/vídeo) conferidos
- [ ] Teste manual no deploy
