
---
name: Tarefa do Projeto
about: Descreva a tarefa, critério de aceite e responsáveis
---

**Descrição**

**Critérios de Aceite**
- [ ] 

**Responsáveis**

**Observações**
