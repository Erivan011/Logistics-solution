
# Roteiro para Vídeo (5–7 min)

1) Abertura (10s)
   - Nome do projeto + link do deploy na tela.
2) Problema e Público-Alvo (40s)
   - Dor real e impacto.
3) Solução (40s)
   - O que o sistema faz.
4) Demo (2–3 min)
   - EDA, Treinamento, Predição.
5) Arquitetura e Tecnologias (40s)
   - Streamlit, scikit-learn, Cloud.
6) Equipe e Papéis (30s)
   - Integrantes e responsabilidades.
7) Resultados e Próximos Passos (40s)
   - Métricas e melhorias futuras.
8) Encerramento (10s)
   - Agradecimentos + links.
