
import streamlit as st
from utils.links import LINKS

st.set_page_config(page_title="Logistics Solution", page_icon="🚚", layout="wide")

st.title("🚚 Logistics Solution — Sistema WEB")
st.markdown(
    """
    Bem-vindo ao **Logistics Solution**, um *template* pronto para você publicar seu
    projeto de Ciência de Dados/Logística como um **Sistema WEB**.

    Use o menu **Pages** (barra lateral) para navegar por **Visão Geral**, **EDA**, **Modelo** e **Predição**.

    > Substitua este texto com a descrição do **problema real** que o seu grupo resolveu (ONG, Projeto Cultural, Extensão ou Profissional).
    """
)

st.info("Você pode editar o conteúdo das páginas em `pages/` e adicionar suas próprias análises e visualizações.")

st.subheader("Links do Projeto")
st.write(f"**Repositório GitHub**: {LINKS['repo']}")
st.write(f"**Deploy (produção)**: {LINKS['deploy']}")
st.write(f"**Vídeo (YouTube)**: {LINKS['video']}")
