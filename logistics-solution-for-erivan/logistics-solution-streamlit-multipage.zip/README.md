
# Logistics Solution — Sistema WEB (Multipáginas)

Este repositório contém um **template multipáginas em Streamlit** para publicar seu projeto de
Ciência de Dados/Logística como um **Sistema WEB** — alinhado aos requisitos de: deploy em Cloud,
versionamento no GitHub, integrantes do grupo e vídeo de apresentação.

## 🚀 Links
- **Deploy (produção)**: _adicione aqui o URL após publicar_
- **Vídeo (YouTube)**: _adicione aqui o link do vídeo (≥ 5 minutos)_

## 👥 Integrantes do Grupo
- Nome (RA) — função
- Nome (RA) — função
- _adicione todos os integrantes (6 a 12)_

## 🧱 Estrutura
```text
.
├── app.py
├── pages/
│   ├── 01_Visão_Geral.py
│   ├── 02_EDA.py
│   ├── 03_Modelo.py
│   └── 04_Predição.py
├── utils/
│   ├── data.py
│   └── links.py
├── requirements.txt
├── .streamlit/config.toml
├── VIDEO_SCRIPT.md
├── LICENSE
└── .gitignore
```

## ⚙️ Como rodar localmente
```bash
pip install -r requirements.txt
streamlit run app.py
```

## ☁️ Deploy rápido (Streamlit Community Cloud)
1. Faça push deste repositório para o GitHub.
2. Acesse https://share.streamlit.io, conecte sua conta e clique em **New app**.
3. Selecione o repositório → branch `main` → arquivo inicial `app.py`.
4. Publique e copie o **URL público** (coloque no topo deste README).

## 📝 Checklist da disciplina
- [ ] Sistema WEB online (link de deploy no topo)
- [x] Versionamento no GitHub
- [ ] Integrantes listados neste README
- [ ] Vídeo (YouTube) adicionado
- [ ] Formulário de entrega (quando disponível)

## 📄 Licença
MIT
