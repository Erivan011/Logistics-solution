
LINKS = {
    'repo': '[SUBSTITUA_PELO_LINK_DO_REPO](https://github.com/SEU_USUARIO/SEU_REPO)',
    'deploy': '[SUBSTITUA_PELO_LINK_DO_DEPLOY](https://example.streamlit.app)',
    'video': '[SUBSTITUA_PELO_LINK_DO_VIDEO](https://youtube.com)'
}
